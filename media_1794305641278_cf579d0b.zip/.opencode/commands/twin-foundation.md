---
description: Dijital ikiz mühendislik şartnamesine göre ilk altyapı görevini planlar.
agent: architect
subagent: true
---

Önce `AGENTS.md`, `docs/11_digital_twin_engineering_spec.md` (§§0, 1, 3, 5, 10–12), `docs/07_tasks.md` ve mevcut kod yapısını oku.

DT-001 için yalnızca fiziksel ağ / hizmet ağı / senaryo / veri kökeni ve temporal sözleşmelerini küçük görevler halinde planla. `docs/05_data_dictionary.md`, `docs/06_architecture.md`, `docs/07_tasks.md`, `docs/08_decisions.md` içine gerektiği kadar ekle. Varsayımsal koordinat/sefer/gerçek zamanlı veri üretme, kod yazma. Tek görev ID'si, girdi ve çıktı şeması, etkilenen dosyalar, testler ve kabul kriteri bildir.
